package com.example.twitterserver.replies;

import org.springframework.data.repository.CrudRepository;

public interface ReplyRepository
    extends CrudRepository<Reply, Integer> {
}
